#include "graphwindow.h"
#include "ui_graphwindow.h"
#include <cmath>

GraphWindow::GraphWindow(QWidget *parent)
    : QWidget(parent),
    ui(new Ui::GraphWindow)
{
    ui->setupUi(this);

    // связи слайдеров
    connect(ui->sliderA, &QSlider::valueChanged, this, &GraphWindow::updateGraph);
    connect(ui->sliderB, &QSlider::valueChanged, this, &GraphWindow::updateGraph);
    connect(ui->sliderC, &QSlider::valueChanged, this, &GraphWindow::updateGraph);

    updateGraph();
}

GraphWindow::~GraphWindow()
{
    delete ui;
}

void GraphWindow::updateGraph()
{
    QVector<double> x, y;

    double scale = ui->sliderA->value() / 10.0;   // масштаб
    double shift = ui->sliderB->value() / 10.0;   // сдвиг
    double range = ui->sliderC->value();          // диапазон

    for (double i = -range; i <= range; i += 0.05) {
        double fx;

        if (i < 0) {
            fx = sin(i);
        }
        else if (i >= 0 && i < 1) {
            fx = sqrt(i);
        }
        else {
            if (fabs(i - 1) < 0.01) continue; // избегаем асимптоты
            fx = 1.0 / (i - 1);
        }

        x.push_back(i * scale + shift);
        y.push_back(fx);
    }

    ui->customPlot->clearGraphs();
    ui->customPlot->addGraph();
    ui->customPlot->graph(0)->setData(x, y);

    ui->customPlot->xAxis->setLabel("X");
    ui->customPlot->yAxis->setLabel("Y");

    ui->customPlot->rescaleAxes();
    ui->customPlot->replot();
}