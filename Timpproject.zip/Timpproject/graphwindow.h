#ifndef GRAPHWINDOW_H
#define GRAPHWINDOW_H

#include <QObject>
#include <QWidget>
#include <QVector>
namespace Ui {
class GraphWindow;
}

class GraphWindow : public QWidget
{
    Q_OBJECT

public:
    explicit GraphWindow(QWidget *parent = nullptr);
    ~GraphWindow();

private slots:
    void updateGraph();

private:
    Ui::GraphWindow *ui;
};

#endif