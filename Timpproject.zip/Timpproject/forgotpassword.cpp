#include "forgotpassword.h"
#include "ui_forgotpassword.h"
#include <QMessageBox>

ForgotPassword::ForgotPassword(QWidget *parent)
    : QWidget(parent),
    ui(new Ui::ForgotPassword)
{
    ui->setupUi(this);
}

ForgotPassword::~ForgotPassword()
{
    delete ui;
}

void ForgotPassword::on_sendButton_clicked()
{
    QString email = ui->emailEdit->text();

    if (email.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Введите почту!");
        return;
    }

    QMessageBox::information(this,
                             "Готово",
                             "Инструкция сброса пароля отправлена на вашу почту");
}

void ForgotPassword::on_backButton_clicked()
{
    emit backRequested();
    this->hide();
}